//Interface for Q15.
public interface Q15Interface {
	public int add(int x, int y);
	public int subtract(int x, int y);
	public int multiply(int x, int y);
	public int divide(int x, int y);
}
