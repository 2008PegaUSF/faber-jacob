package OtherPackage;

public class ExternalClass {
	private float f1;
	private float f2;
	
	public ExternalClass(float f1, float f2) {
		this.f1 = f1;
		this.f2 = f2;
	}
	
	public float getFloat1() {
		return f1;
	}
	
	public float getFloat2() {
		return f2;
	}
}
