
public abstract class Q18Superclass {
	//The three methods as described in Q18 requirements
	public abstract boolean containsUppercaseLetters(String str);
	public abstract String toUpperCase(String str);
	public abstract int toIntPlusTen(String str);
}
